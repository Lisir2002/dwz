<?php
return array (
  'aaaaa' => 'https://dwz.ge',
);