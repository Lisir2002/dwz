<?php
return array (
  0 => 'https://dwz.ge',
);