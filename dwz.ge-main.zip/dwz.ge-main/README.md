# dwz.ge
一个不到10KB的短网址程序

演示站点：https://dwz.ge/

魔改，优点如下：

1：不到10k

2：没有后台

3：无需数据库

4：支持域名黑名单

5：支持设置数字自增

6：支持放在二级目录

7：支持PHP5到8

8：生成速度特快

9：支持API：https://dwz.ge/create.php?url=长网址

自行修改config.php配置文件 .htaccess打开复制到Nginx伪静态文件

单击链接复制，再点一下打开

![images](https://file.lzfh.com/3buw30Gf)
